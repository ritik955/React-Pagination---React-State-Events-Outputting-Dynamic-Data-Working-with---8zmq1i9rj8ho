const fetchPosts = async (page, limit) => {
    // optionally write fetching logic here or somewhere else
}

export { fetchPosts }