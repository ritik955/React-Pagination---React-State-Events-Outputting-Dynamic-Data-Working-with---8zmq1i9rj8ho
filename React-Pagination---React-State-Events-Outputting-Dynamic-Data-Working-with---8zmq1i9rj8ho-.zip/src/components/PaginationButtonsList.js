import React from 'react'
const PaginationButtonsList = () => {

    return (
        <div className="pagination-buttons-list">

        </div>
    )
}

export { PaginationButtonsList }

