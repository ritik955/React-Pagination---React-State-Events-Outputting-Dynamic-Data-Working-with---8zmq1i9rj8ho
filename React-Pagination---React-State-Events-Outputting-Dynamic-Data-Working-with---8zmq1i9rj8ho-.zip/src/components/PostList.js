import React from 'react'


const PostList = () => {
    
    return (
        <>

        </>
    )
}

export { PostList }
