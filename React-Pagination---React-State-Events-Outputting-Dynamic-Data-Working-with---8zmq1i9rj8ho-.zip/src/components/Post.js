import React from 'react'
const Post = () => {
    return (
        <div className="post">

        </div>
    )
}

export { Post }
